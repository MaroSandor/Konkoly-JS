import "../20220518/math";

const matrix1 = math.matrix([
    [1, 4],
    [5, 7],
    [6, 0]
]);
const matrix2 = math.matrix([
    [2, 5, 6],
    [0, 7, 1],
    [5, -2, 3],
    [1, 2, 3]
]);

const matrixEredmeny = math.multiply(matrix2, matrix1);

document.getElementById("id").innerHTML = matrixEredmeny;